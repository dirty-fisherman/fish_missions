interface Window {
  invokeNative: (native: string, arg: string) => void;
  GetParentResourceName: () => string;
}
